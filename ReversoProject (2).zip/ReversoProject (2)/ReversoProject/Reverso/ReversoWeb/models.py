from django.db import models


# Create your models here.
class Contact(models.Model):
    contact_id = models.AutoField(primary_key=True)
    name = models.CharField(max_length=50)
    email = models.CharField(max_length=70, default="")
    phone = models.CharField(max_length=70, default="")
    city = models.CharField(max_length=70, default="")
    msg = models.CharField(max_length=500, default="")
    def __str__(self):
        return self.name

class Demo(models.Model):
    demo_id = models.AutoField(primary_key=True)
    name = models.CharField(max_length=50)
    email = models.CharField(max_length=70, default="")
    phone = models.CharField(max_length=70, default="")
    city = models.CharField(max_length=70, default="")
    course = models.CharField(max_length=70, default="")

    def __str__(self):
        return self.name

class Payment(models.Model):
    pay_id = models.AutoField(primary_key=True)
    name = models.CharField(max_length=50)
    email = models.CharField(max_length=70, default="")
    phone = models.CharField(max_length=70, default="")
    city = models.CharField(max_length=70, default="")

    def __str__(self):
        return self.name

class Student(models.Model):
    student_id = models.AutoField(primary_key=True)
    name = models.CharField(max_length=50)
    email = models.CharField(max_length=70, default="")
    phone = models.CharField(max_length=70, default="")
    gender = models.CharField(max_length=70, default="")
    marital_status = models.CharField(max_length=70, default="")

    course_enrolled= models.CharField(max_length=70, default="")
    name_guardian = models.CharField(max_length=70, default="")
    address = models.CharField(max_length=70, default="")
    dob = models.CharField(max_length=70, default="")
    total_experience = models.CharField(max_length=70, default="")
    degree = models.CharField(max_length=70, default="")
    college = models.CharField(max_length=70, default="")
    percentage = models.CharField(max_length=70, default="")
    graduation_date = models.CharField(max_length=70, default="")
    upload = models.ImageField(upload_to='Media/Image', null=True, blank=True,default="")

    emergency_name = models.CharField(max_length=70, default="")
    emergency_relationship = models.CharField(max_length=70, default="")
    emergency_phone = models.CharField(max_length=70, default="")

    current_org = models.CharField(max_length=70, default="")
    current_pos = models.CharField(max_length=70, default="")
    duration1 = models.CharField(max_length=70, default="")

    second_org = models.CharField(max_length=70, default="")
    second_pos = models.CharField(max_length=70, default="")
    duration2 = models.CharField(max_length=70, default="")

    third_org = models.CharField(max_length=70, default="")
    third_pos = models.CharField(max_length=70, default="")
    duration3 = models.CharField(max_length=70, default="")

    fourth_org = models.CharField(max_length=70, default="")
    fourth_pos = models.CharField(max_length=70, default="")
    duration4 = models.CharField(max_length=70, default="")

    fifth_org = models.CharField(max_length=70, default="")
    fifth_pos = models.CharField(max_length=70, default="")
    duration5 = models.CharField(max_length=70, default="")

    def __str__(self):
        return self.name

class Resume(models.Model):
    resume_id = models.AutoField(primary_key=True)
    name = models.CharField(max_length=50)
    email = models.CharField(max_length=70, default="")
    phone = models.CharField(max_length=70, default="")
    job_title = models.CharField(max_length=70, default="")
    total_experience = models.CharField(max_length=70, default="")
    current_location = models.CharField(max_length=70, default="")
    file = models.FileField(upload_to='Media/Documents',default="")
    msg = models.CharField(max_length=500, default="")
   
    #resume-models.FileField
    def __str__(self):
        return self.name


class Employee(models.Model):
    employee_id = models.AutoField(primary_key=True)
    company_name = models.CharField(max_length=50)
    company_website = models.CharField(max_length=70, default="")
    subject = models.CharField(max_length=70, default="")
    address = models.CharField(max_length=160, default="")

    job_title = models.CharField(max_length=70, default="")
    number_of_openings = models.CharField(max_length=70, default="")
    key_skills = models.CharField(max_length=70, default="")
    job_location = models.CharField(max_length=50, default="")
    experience = models.CharField(max_length=50, default="")
    qualification = models.CharField(max_length=50, default="")

    email = models.CharField(max_length=50, default="")
    phone = models.CharField(max_length=50, default="")
    contact_person = models.CharField(max_length=50, default="")
    designation = models.CharField(max_length=50, default="")

    #resume-models.FileField
    def __str__(self):
        return self.company_name
