from django.contrib import admin
from .models import Contact, Demo, Payment, Student, Resume, Employee
admin.site.register(Contact)
admin.site.register(Demo)
admin.site.register(Payment)
admin.site.register(Student)
admin.site.register(Resume)
admin.site.register(Employee)


# Register your models here.
