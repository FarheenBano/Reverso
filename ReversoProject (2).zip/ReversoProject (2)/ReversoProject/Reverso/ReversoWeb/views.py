from urllib import request
from django.shortcuts import render,HttpResponse
from .models import Contact,Demo,Payment, Student, Resume, Employee
from django.contrib import messages

# Create your views here.
def index(request):
    # return HttpResponse("Hello")
    return render(request,'index.html')

def job_gurantee(request):
    # return HttpResponse("Hello")
    return render(request,'job_gurantee.html')

def protocol_testing(request):
    #return HttpResponse("Hello")
     return render(request,'protocol_testing.html')

def about(request):
    # return HttpResponse("Hello")
    return render(request,'about.html')

def contact(request):
    if request.method == "POST":
        name = request.POST.get('name', '')
        email = request.POST.get('email', '')
        phone = request.POST.get('phone', '')
        city = request.POST.get('city', '')
        msg = request.POST.get('msg', '')
        contact = Contact(name=name, email=email, phone=phone, city=city, msg=msg)
        contact.save()
    return render(request, 'contact.html')
    # return HttpResponse("Hello")

  #  return render(request,'contact.html')

def free_demo(request):
    if request.method == "POST":
        name = request.POST.get('name', '')
        email = request.POST.get('email', '')
        phone = request.POST.get('phone', '')
        city = request.POST.get('city', '')
        course = request.POST.get('course', '')
        freedemo = Demo(name=name, email=email, phone=phone, city=city, course=course)
        freedemo.save()
    return render(request, 'free_demo.html')

def fee_payment(request):
    return render(request,'fee_payment.html')

def protocol_payment(request):
    if request.method == "POST":
        name = request.POST.get('name', '')
        email = request.POST.get('email', '')
        phone = request.POST.get('phone', '')
        city = request.POST.get('city', '')
        fee_payment = Payment(name=name, email=email, phone=phone, city=city)
        fee_payment.save()
    return render(request,'protocol_payment.html')

def view(request):
    context = {'metadata': {'attr-1': 'value1', 'attr-2': 'value2'}}
    return render(request, 'base.html', context)


def faq(request):
    return render(request,'faq.html')

def python_training(request):
    return render(request,'python_training.html')


def python_training(request):
    return render(request,'python_training.html')


def java_training(request):
    return render(request,'java_training.html')


def c_prog(request):
    return render(request,'c_prog.html')


def telecom(request):
    return render(request,'telecom.html')


def industrial_training(request):
    return render(request,'industrial_training.html')


def technical(request):
    return render(request,'technical.html')

def student_information_form(request):
        if request.method == "POST":
            name = request.POST.get('name', '')
            email = request.POST.get('email', '')
            phone = request.POST.get('phone', '')
            gender = request.POST.get('gender', '')
            marital_status = request.POST.get('marital_status', '')
            course_enrolled = request.POST.get('course_enrolled', '')
            name_guardian = request.POST.get('name_guardian', '')
            address = request.POST.get('address', '')
            dob = request.POST.get('dob', '')
            total_experience = request.POST.get('total_experience', '')
            degree = request.POST.get('degree', '')
            college =request.POST.get('college', '')
            percentage = request.POST.get('percentage', '')
            graduation_date = request.POST.get('graduation_date', '')
            upload = request.FILES['upload']

            emergency_name = request.POST.get('emergency_name', '')
            emergency_relationship = request.POST.get('emergency_relationship', '')
            emergency_phone = request.POST.get('emergency_phone', '')

            current_org = request.POST.get('current_org', '')
            current_pos = request.POST.get('current_pos', '')
            duration1 = request.POST.get('duration1', '')

            second_org = request.POST.get('second_org', '')
            second_pos = request.POST.get('second_pos', '')
            duration2 = request.POST.get('duration2', '')

            third_org = request.POST.get('third_org', '')
            third_pos = request.POST.get('third_pos', '')
            duration3 = request.POST.get('duration3', '')

            fourth_org = request.POST.get('fourth_org', '')
            fourth_pos = request.POST.get('fourth_pos', '')
            duration4 = request.POST.get('duration4', '')

            fifth_org = request.POST.get('fifth_org', '')
            fifth_pos = request.POST.get('fifth_pos', '')
            duration5 = request.POST.get('duration5', '')

            print(current_org)

            student = Student(name=name, email=email, phone=phone, gender=gender,marital_status=marital_status,course_enrolled=course_enrolled,
                              name_guardian=name_guardian,address=address,dob=dob,total_experience=total_experience,
                              degree=degree,college=college,percentage=percentage,graduation_date=graduation_date,upload=upload,
                              emergency_name=emergency_name,emergency_phone=emergency_phone,emergency_relationship=emergency_relationship,
                              current_org=current_org,current_pos=current_pos,duration1=duration1,
                              second_org=second_org,second_pos=second_pos,duration2=duration2,
                              third_org=third_org,third_pos=third_pos,duration3=duration3,
                              fourth_org=fourth_org,fourth_pos=fourth_pos,duration4=duration4,
                              fifth_org=fifth_org,fifth_pos=fifth_pos,duration5=duration5
                              )

            student.save()
            messages.success(request, 'Your data has been submitted Successfully.')
        return render(request,'student_information_form.html')


def employee(request):
    if request.method == "POST":
        company_name = request.POST.get('company_name', '')
        company_website = request.POST.get('company_website', '')
        subject = request.POST.get('subject', '')
        address = request.POST.get('address', '')

        job_title = request.POST.get('job_title', '')
        number_of_openings=request.POST.get('number_of_openings','')
        key_skills=request.POST.get('key_skills','')
        job_location=request.POST.get('job_location','')
        experience=request.POST.get('experience','')
        qualification=request.POST.get('qualification','')

        email = request.POST.get('email', '')
        phone = request.POST.get('phone', '')
        contact_person = request.POST.get('contact_person', '')
        designation = request.POST.get('designation', '')

        employee = Employee(company_name=company_name,company_website=company_website,subject=subject,address=address,
                            job_title=job_title,number_of_openings=number_of_openings,key_skills=key_skills,job_location=job_location,experience=experience,qualification=qualification,
                            email=email,phone=phone,contact_person=contact_person,designation=designation
                            )
        employee.save()
        messages.success(request, 'Your data has been submitted Successfully.')

    return render(request,'employee.html')

def resume(request):
    if request.method == "POST":
        name = request.POST.get('name', '')
        email = request.POST.get('email', '')
        phone = request.POST.get('phone', '')
        job_title = request.POST.get('job_title', '')
        total_experience=request.POST.get('total_experience','')
        current_location=request.POST.get('current_location','')
        file = request.FILES['upload']
        msg=request.POST.get('msg','')
        resume = Resume(name=name, email=email, phone=phone, job_title=job_title,total_experience=total_experience,current_location=current_location,file=file,msg=msg)
        resume.save()
        messages.success(request, 'Your data has been submitted Successfully.')

    return render(request,'resume.html')

def student_feedback(request):
    return render(request,'student_feedback.html')

def feedback_demo_class(request):
    return render(request,'feedback_demo_class.html')

def staffing_services(request):
    return render(request,'staffing_services.html')


def web_solutions_services(request):
    return render(request,'web-solutions-services.html')


def quotation(request):
    return render(request,'quotation.html')


def services(request):
    return render(request,'services.html')


def training_placement(request):
    return render(request,'training_placement.html')


def courses(request):
    return render(request,'courses.html')
